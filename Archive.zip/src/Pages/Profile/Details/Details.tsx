import styles from "./Details.module.scss";

export const Details = () => {
  return (
    <div className={styles.details}>
      <h1>Реквизиты:</h1>
      <p>Нет данных</p>
    </div>
  );
};
